# Archive du Devoir 1

Version initiale (non ERC-721) du système : contrat `CertificateRegistry` avec gestion des admins par mapping.

- `contracts/CertificateRegistry.sol` : contrat du Devoir 1
- `test/CertificateRegistry.test.js` : 9 tests (tous réussis à l'époque)
- `scripts/deploy.js` et `hardhat.config.js` : déploiement local du Devoir 1

Ces fichiers sont conservés pour l'historique. Ils ne sont pas compilés par le projet principal (Devoir 2, voir `../README.md`).
